from projects.auth.ui import UI

UI().main()